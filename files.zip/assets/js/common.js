// common loader for resume JSON
async function loadData(){
  const res = await fetch('data/resume.json');
  if(!res.ok) throw new Error('Failed to load resume data');
  const data = await res.json();
  return data;
}

// small helper to create an element with optional class and text
function el(tag, cls, txt){
  const e = document.createElement(tag);
  if(cls) e.className = cls;
  if(txt !== undefined) e.textContent = txt;
  return e;
}