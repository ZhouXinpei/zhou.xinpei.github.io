// Simple data-driven renderer with language toggle and interactive features.
// Loads data/resume.json and fills the page.

const state = { data: null, lang: 'en' };

async function loadData(){
  const res = await fetch('data/resume.json');
  state.data = await res.json();
  renderAll();
}

function t(key){
  // basic i18n for UI labels (falls back to key)
  const ui = { contact: {en:'Contact',fr:'Contact',zh:'联系方式'},
               profile:{en:'Profile',fr:'Profil',zh:'个人简介'},
               experience:{en:'Professional Experience',fr:'Expérience',zh:'工作经历'},
               education:{en:'Education',fr:'Éducation',zh:'教育经历'},
               publications:{en:'Selected Publications',fr:'Publications',zh:'出版物'},
               skills:{en:'Languages & Technical Skills',fr:'Compétences',zh:'语言与技能'}};
  return ui[key] ? (ui[key][state.lang]||ui[key].en) : key;
}

function renderAll(){
  if(!state.data) return;
  document.getElementById('year').textContent = new Date().getFullYear();
  document.getElementById('name').textContent = state.data.name;
  document.getElementById('subname').textContent = state.data.native_name || '';
  document.getElementById('profileText').textContent = state.data.profile[state.lang] || state.data.profile.en;
  document.getElementById('emailLink').href = 'mailto:' + state.data.contact.email;
  document.getElementById('emailLink').textContent = state.data.contact.email;
  document.getElementById('phone').textContent = state.data.contact.phone;
  document.getElementById('address').textContent = state.data.contact.address;
  // CV download
  const cv = state.data.contact.cv[state.lang] || state.data.contact.cv.en;
  document.getElementById('downloadCv').href = cv;

  // timeline
  const timelineNode = document.getElementById