// Renders Experience page with filter by sector
loadData().then(data => {
  const timeline = document.getElementById('timeline');
  const sectors = new Set();
  data.experience.forEach(item => sectors.add(item.sector));
  const filter = document.getElementById('sectorFilter');
  ['all', ...Array.from(sectors)].forEach(s => {
    const opt = document.createElement('option'); opt.value = s; opt.textContent = s === 'all' ? 'All' : s;
    filter.appendChild(opt);
  });

  function render(filterSector){
    timeline.innerHTML = '';
    const items = data.experience
      .filter(i => filterSector === 'all' ? true : i.sector === filterSector)
      .sort((a,b)=> (b.start||'').localeCompare(a.start||''));
    items.forEach(i => {
      const node = el('div','timeline-item');
      node.innerHTML = `<div class="meta"><strong>${i.period}</strong> — <span class="muted">${i.sector} • ${i.organization}, ${i.location}</span></div>
        <h3>${i.title}</h3>
        <p>${i.description}</p>`;
      timeline.appendChild(node);
    });
  }

  filter.addEventListener('change', () => render(filter.value));
  render('all');
}).catch(e => console.error(e));