// Renders Education page
loadData().then(data => {
  const list = document.getElementById('educationList');
  data.education.degreePrograms.forEach(item => {
    const li = el('li');
    const h = el('h3', '', `${item.period} — ${item.title}`);
    const inst = el('p', 'muted', `${item.institution} • ${item.location}`);
    const details = el('p', '', item.notes || '');
    li.append(h, inst, details);
    list.appendChild(li);
  });

  const exch = document.getElementById('exchangeList');
  data.education.exchangePrograms.forEach(item => {
    const li = el('li', '', `${item.period} — ${item.program} — ${item.institution} (${item.notes || ''})`);
    exch.appendChild(li);
  });
}).catch(e => console.error(e));