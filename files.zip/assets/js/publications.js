// Renders Publications page with search + filter by type
loadData().then(data => {
  const list = document.getElementById('pubList');
  const search = document.getElementById('pubSearch');
  const filter = document.getElementById('pubFilter');

  const types = new Set(data.publications.map(p => p.type || 'Article'));
  filter.appendChild(new Option('All','all'));
  types.forEach(t => filter.appendChild(new Option(t,t)));

  function render(){
    const q = search.value.trim().toLowerCase();
    const ft = filter.value;
    list.innerHTML = '';
    data.publications
      .filter(p => (ft === 'all' || (p.type || 'Article') === ft))
      .filter(p => q === '' || (p.title + ' ' + (p.notes||'') + ' ' + (p.authors||'')).toLowerCase().includes(q))
      .forEach(p => {
        const li = el('li');
        const h = el('h3','', p.title);
        const meta = el('p','muted', `${p.authors} — ${p.venue} (${p.year})`);
        const notes = el('p','', p.notes || '');
        li.append(h, meta, notes);
        list.appendChild(li);
      });
  }

  search.addEventListener('input', render);
  filter.addEventListener('change', render);
  render();
}).catch(e => console.error(e));